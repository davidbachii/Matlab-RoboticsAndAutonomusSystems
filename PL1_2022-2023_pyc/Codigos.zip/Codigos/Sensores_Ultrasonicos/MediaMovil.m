setenv('ROS_MASTER_URI','http://192.168.1.168:11311') % Aqui poner la ip de ubuntu 
setenv('ROS_IP','192.168.1.1') % Aqui poner la ip de windows
rosinit % Inicialización de ROS
sonarfront = rossubscriber('/robot0/sonar_0'); % No se suscribe al sonar 
% Inicializar variables
distances = [];
filtered_distances = [];
time = [];
% Leer el mensaje del sensor de sonar
for i = 0:1000
    sonarMsgF = receive(sonarfront, 1);
    % Extraer la distancia a las paredes
    frontDist = sonarMsgF.Range_;
    % Agregar la distancia a la lista de distancias
    distances = [distances, frontDist];
    % Aplicar el filtro media móvil si hay suficientes valores
    if length(distances) >= 5
        % Calcular la media de los últimos 5 valores
        filteredDist = mean(distances(end-4:end));
        % Agregar la distancia filtrada a la lista correspondiente
        filtered_distances = [filtered_distances, filteredDist];
    else
        % Si hay menos de 5 valores, agregar la distancia sin filtrar
        filtered_distances = [filtered_distances, frontDist];
    end
    % Actualizar el tiempo
    time = [time, i];
end
% Graficar las distancias originales y filtradas
%Esta linea compara 2 graficas 
%plot(time, distances, 'b-', time, filtered_distances, 'r-');
plot(time, filtered_distances);
xlabel('Tiempo');
ylabel('Distancia');
