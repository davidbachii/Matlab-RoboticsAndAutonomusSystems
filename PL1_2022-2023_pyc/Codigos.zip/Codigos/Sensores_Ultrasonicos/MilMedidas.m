setenv('ROS_MASTER_URI','http://172.29.29.56:11311') % Aqui poner la ip de ubuntu 
setenv('ROS_IP','172.29.29.54') % Aqui poner la ip de windows
rosinit % Inicialización de ROS
sonarfront = rossubscriber('/robot0/sonar_0'); %No se suscribe al sonar 
% Leer el mensaje del sensor de sonar
distances = [];
time = [];
for i = 0:1000
    sonarMsgF = receive(sonarfront, 1);
    % Extraer la distancia a las paredes
    frontDist = sonarMsgF.Range_;
    % Activar los controladores en relacion a las paredes q hay
    distances = [distances, frontDist];
    time = [time, i];
end
plot(time,distances);
xlabel('Tiempo');
ylabel('Distancia');
