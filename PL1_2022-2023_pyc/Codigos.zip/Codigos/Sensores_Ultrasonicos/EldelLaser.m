setenv('ROS_MASTER_URI','http://192.168.1.108:11311') % Aqui poner la ip de ubuntu 
setenv('ROS_IP','192.168.1.1') % Aqui poner la ip de windows
rosinit % Inicialización de ROS
laser = rossubscriber('/robot0/laser_1'); % Suscripción al láser

% Leer el mensaje del sensor de láser
laserMsg = receive(laser, 1);
ranges = laserMsg.Ranges;
disp(laserMsg);
dist = 6;
comp = 60;
%cuadrante 3
cont3 = 0;
for i=1:50
    if ranges(i) < dist
        cont3 = cont3 + 1;
    end
end
%cuadrante 2
cont2 = 0;
for i=350:400
    if ranges(i) < dist
        cont2 = cont2 + 1;
    end
end
izqda = cont3+cont2;
%cuadrante 1
detras = 0;
for i=50:150
    if ranges(i) < dist
        detras = detras + 1;
    end
end
%cuadrante 4
derecha = 0;
for i=150:250
    if ranges(i) < dist
        derecha = derecha + 1;
    end
end
delante = 0;
for i=250:350
    if ranges(i) < dist
        delante = delante + 1;
    end
end
%comprobamos zonas
if detras> comp 
    disp('Hay pared detrás')
end
if izqda> comp
    disp('Hay pared a la izquierda')
end
if delante > comp
    disp('Hay pared delante')
end
if derecha > comp
    disp('Hay pared a la derecha')
end



