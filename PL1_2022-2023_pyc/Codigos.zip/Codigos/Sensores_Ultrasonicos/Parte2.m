setenv('ROS_MASTER_URI','http://192.168.1.108:11311') % Aqui poner la ip de ubuntu 
setenv('ROS_IP','192.168.1.1') % Aqui poner la ip de windows
rosinit % Inicialización de ROS
sonarfront = rossubscriber('/robot0/sonar_0');  
sonarback = rossubscriber('/robot0/sonar_5');
sonarder = rossubscriber('/robot0/sonar_3');
sonarizq = rossubscriber('/robot0/sonar_7');
sonarizq2 = rossubscriber('/robot0/sonar_6');
% Leer el mensaje del sensor de sonar
sonarMsgF = receive(sonarfront, 1);
sonarMsgB = receive(sonarback, 1);
sonarMsgD = receive(sonarder, 1);
sonarMsgI = receive(sonarizq, 1);
sonarMsgI2 = receive(sonarizq2, 1);
% Extraer la distancia a las paredes
izqDist = sonarMsgI.Range_;
izqDist2 = sonarMsgI.Range_;
derDist = sonarMsgD.Range_;  
frontDist = sonarMsgF.Range_;
backDist = sonarMsgB.Range_;

% Definimos la dist max a la q debe detectar pared
distm = 6;
% Activar los controladores en relacion a las paredes q hay
disp(izqDist);
disp(izqDist2)
disp(derDist);
disp(frontDist);
disp(backDist);
if izqDist < distm && izqDist2 < distm 
    disp('Hay una pared a la izquierda');
end
if derDist < distm
    disp('Hay una pared a la derecha');
end
if frontDist < distm
    disp('Hay una pared enfrente');
end
if backDist < distm
    disp('Hay una pared detras');
end