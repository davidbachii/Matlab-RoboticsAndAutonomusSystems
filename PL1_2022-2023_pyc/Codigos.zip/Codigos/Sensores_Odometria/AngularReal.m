%% INICIALIZACIÓN DE ROS
% Se definen las variables de entorno ROS_MASTER_URI (ip del Master) y ROS_IP (IP
%de la máquina donde se ejecuta Matlab). Si se está conectado a la misma red, la
%variable ROS_IP no es necesario definirla.
setenv('ROS_MASTER_URI','http://172.29.30.173:11311')  %Aqui poner la ip de ubuntu 
setenv('ROS_IP','172.29.30.72') %Aqui poner la ip de windows
rosinit % Inicialización de ROS
%% DECLARACIÓN DE SUBSCRIBERS
odom=rossubscriber('/pose'); % Subscripción a la odometría

%% DECLARACIÓN DE PUBLISHERS
pub_enable=rospublisher('/cmd_motor_state','std_msgs/Int32');
pub = rospublisher('/cmd_vel', 'geometry_msgs/Twist'); %
%declaración mensaje
msg_enable_motor=rosmessage(pub_enable);
%activar motores enviando enable_motor = 1
msg_enable_motor.Data=1;
msg=rosmessage(pub) %% Creamos un mensaje del tipo declarado en "pub (geometry_msgs/Twist)
send(pub_enable,msg_enable_motor);

% Rellenamos los campos del mensaje para que el robot avance a 0.2 m/s
% Velocidades lineales en x,y y z (velocidades en y o z no se usan en robots diferenciales y entornos 2D)
msg.Angular.Z=0.9;
send(pub,msg);

%% Definimos la perodicidad del bucle (10 hz)
r = robotics.Rate(10);
pause(1);
%% Nos aseguramos recibir un mensaje relacionado con el robot "robot0"
while (strcmp(odom.LatestMessage.ChildFrameId,'base_link')~=1)
 odom.LatestMessage
end


%% Inicializamos la primera posición (coordenadas x,y,z)
initpos=odom.LatestMessage.Pose.Pose.Orientation;
 
%% Inicializar un array vacío para almacenar las distancias
distances = [];
%% Inicializar un array vacío para almacenar las diferencias
differences = []; 
%% Bucle de control infinito
while (1)
%% Obtenemos la posición actual
    pos=odom.LatestMessage.Pose.Pose.Orientation;
    qpos = [pos.W, pos.X, pos.Y, pos.Z];
% Convertir el resultado anterior en ángulos de Euler en radianes
  [yaw, pitch, roll] = quat2angle(qpos, 'ZYX');

  % Imprimir los valores de los ángulos en radianes
  disp(['Roll (radianes): ', num2str(roll)]);
  disp(['Pitch (radianes): ', num2str(pitch)]);
  disp(['Yaw (radianes): ', num2str(yaw)]);
  distances = [distances,yaw];
%% Si el robot se ha desplazado más de un metro detenemos el robot (velocidad lineal 0) y salimos del bucle
    if (yaw>3.0)
        msg.Angular.Z=0;
        % Comando de velocidad
        send(pub,msg);
        % Salimos del bucle de control
        break;
    else
    % Comando de velocidad
        send(pub,msg);
    end
% Temporización del bucle según el parámetro establecido en r
waitfor(r)
end
%% Calcular el maximo de la distancia obtenida menos la anterior


for i = 2:length(distances)
    diff = distances(i) - distances(i-1);
    differences = [differences, diff];
    disp(differences);
   

end
 max_difference = max(differences);
 disp(max_difference);
%% DESCONEXIÓN DE ROS
rosshutdown; 
