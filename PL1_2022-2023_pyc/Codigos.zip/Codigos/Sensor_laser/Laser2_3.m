setenv('ROS_MASTER_URI','http://172.29.30.173:11311')  %Aqui poner la ip de ubuntu 
setenv('ROS_IP','172.29.30.72') %Aqui poner la ip de windows
rosinit % Inicialización de ROS
laser = rossubscriber('/scan'); % Suscripción al láser
distances = [];


% Leer el mensaje del sensor de láser
laserMsg = receive(laser, 1);
disp(laserMsg.Ranges);
distances = [distances, laserMsg.Ranges];





plot(distances);
xlabel('Tiempo');
ylabel('Distancia');